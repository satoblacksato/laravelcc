<?php

namespace App\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class CoreModel extends Model
{
 
    public function scopeSearch($query,$name){
    	return $query->where('nombre','LIKE',"%$name%");
    }
}