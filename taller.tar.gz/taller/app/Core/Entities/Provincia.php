<?php

namespace App\Core\Entities;

use Illuminate\Database\Eloquent\Model;

class Provincia extends CoreModel
{
    protected $table="provincia";

    protected $fillable=['nombre'];

    public function  ciudades(){
    	return $this->hasMany('App\Core\Entities\Ciudad');
    }


}
