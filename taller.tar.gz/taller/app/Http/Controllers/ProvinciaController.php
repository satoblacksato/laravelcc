<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Core\Entities\Provincia;
use DB;
class ProvinciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        /*$provincias=Provincia::orderBy('id','ASC')->paginate(4);*/
        $provincias=Provincia::search($request->scope)->
        orderBy('id','ASC')->paginate(4);
       return view('provincia.index')->with([
            'mensaje'=>'parametro hola', 
            'provincias' =>$provincias
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('provincia.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

DB::transaction(function () use($request){
     $objProvincia=new Provincia();
        $objProvincia->nombre=$request->nombre;
        $objProvincia->save();
});
       return redirect()->route('provincia.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $objProvincia=Provincia::find($id);
        return view('provincia.edit')->with('objProvincia',$objProvincia);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       DB::transaction(function () use($request,$id){
     $objProvincia=Provincia::find($id);
        $objProvincia->nombre=$request->nombre;
        $objProvincia->save();
});
       return redirect()->route('provincia.index');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

DB::transaction(function () use($id){
     $objProvincia=Provincia::find($id);
       
        $objProvincia->delete();
});
       return redirect()->route('provincia.index');


    }
}
