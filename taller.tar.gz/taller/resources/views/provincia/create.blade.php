formulario:

{!! Form::open(['route' => 'provincia.store','method'=>'POST']) !!}
    

{!! Form::text('nombre',null,['class'=>'texto','required'=>'required','id'=>'nombre']) !!}


{!! Form::close() !!}
