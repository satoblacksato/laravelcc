formulario:

{!! Form::open(['route' => ['provincia.update',$objProvincia],'method'=>'PUT']) !!}
    

{!! Form::text('nombre',$objProvincia->nombre,['class'=>'texto','required'=>'required','id'=>'nombre']) !!}


{!! Form::close() !!}