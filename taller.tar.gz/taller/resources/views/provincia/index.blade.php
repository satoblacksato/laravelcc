hola vista  {{ $mensaje }}


{!! Form::open(['route' => 'provincia.index','method'=>'GET']) !!}
    

{!! Form::text('scope',null,['class'=>'texto','required'=>'required','id'=>'nombre']) !!}


{!! Form::close() !!}




<a href="{{ route('provincia.create') }}">CREAR</a>
<table>
	<tr>
	<th>ID</th>
	<th>Nombre</th>
<th>acciones</th></tr>

@foreach($provincias as $provincia)
<tr>
	<td>{{ $provincia->id }}</td>
	<td>{{ $provincia->nombre }}</td>
	<td><a href="{{ route('provincia.edit',$provincia->id)}}">EDITAR</a>
<a href="{{ route('provincia.destroy',$provincia->id)}}">ELIMINAR</a>
	</td>
</tr>
@endforeach
</table>
{!! $provincias->render() !!}